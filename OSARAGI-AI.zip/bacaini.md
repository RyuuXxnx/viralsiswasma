/* Credits Shyo Edit Butes🗿☕

𝗯𝗮𝗰𝗮 𝗶𝗻𝗶 𝘀𝗲𝗯𝗲𝗹𝘂𝗺 𝗺𝗮𝗸𝗮𝗶

[ BASE ] Kyamie ayam
[ Pengembang ] Butes kuntul
[ Sensei ] ShyoID
[ Type Script ]  Case
[ Baileys ] Kyami titit
[ Support ] All Pengguna SC Bot 

Link Script : 
https://whatsapp.com/channel/0029Vb6TWAfFMqrejcazn945

Link Script 2: 
https://chat.whatsapp.com/D4RWjphCYuYKnyeRacyjg2

Jangan Delete Credits gw 


Whatsapp : https://wa.me//6282176642989
Tele : t.me/@Shyoaja 
Youtube : ShyoCannn
Tiktok : shyonotsepuh

*/Bebas Mau lu apain yg penting jan hapus ini

